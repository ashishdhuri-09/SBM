import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class employee {
    public void einsertUpdateDeleteStudent(char operation,Integer eid, String efname,
            String elname,String eadhar,String eaccount,String eblood,String ebdate,String esex ,String emobile, String eaddress)
    {
        Connection con= MyConnection.getConnection();
        PreparedStatement ps;
     if (operation== 'e') //insertion
     {
            try {
                ps=con.prepareStatement("INSERT INTO employee(`NAME`, `SURNAME`, `AADHAR_NUMBER`, `ACCOUNT_NUMBER`, `BLOOD_GROUP`, `BIRTH_DATE`, `SEX`, `MOBILE_NUMBER`, `ADDRESS`) VALUES (?,?,?,?,?,?,?,?,?)");
           ps.setString(1,efname);
           ps.setString(2,elname);
           ps.setString(3,eadhar);
           ps.setString(4,eaccount);
           ps.setString(5,eblood);
           ps.setString(6,ebdate);
           ps.setString(7,esex);
           ps.setString(8,emobile);
           ps.setString(9,eaddress);
            if(ps.executeUpdate()>0)
            {
                JOptionPane.showMessageDialog(null,"New Employee Added");
            }
            
            } catch (SQLException ex) {
                Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
            }
     }
     if (operation== 'c') //change
     {
            try {
                ps=con.prepareStatement("UPDATE `employee` SET `NAME`=?,`SURNAME`=?,`AADHAR_NUMBER`=?,`ACCOUNT_NUMBER`=?,`BLOOD_GROUP`=?,`BIRTH_DATE`=?,`SEX`=?,`MOBILE_NUMBER`=?,`ADDRESS`=? WHERE `ID`=?");
           ps.setString(1,efname);
           ps.setString(2,elname);
           ps.setString(3,eadhar);
           ps.setString(4,eaccount);
           ps.setString(5,eblood);
           ps.setString(6,ebdate);
           ps.setString(7,esex);
           ps.setString(8,emobile);
           ps.setString(9,eaddress);
           ps.setInt(10,eid);
            if(ps.executeUpdate()>0)
            {
                JOptionPane.showMessageDialog(null,"Employee record edited");
            }
            
            } catch (SQLException ex) {
                Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
            }
     }
     if (operation== 'r') //remove
     {
            try {
                ps=con.prepareStatement("DELETE FROM `employee` WHERE `ID`=?");
           
           ps.setInt(1,eid);
            if(ps.executeUpdate()>0)
            {
                JOptionPane.showMessageDialog(null,"Employee record deleted");
            }
            
            } catch (SQLException ex) {
                Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
            }
     }
    }
     public void efillStudentJtabel(JTable table, String valueToSearch)
    {
        Connection con=MyConnection.getConnection();
        PreparedStatement ps;
        try {
            ps=con.prepareStatement("SELECT * FROM employee WHERE CONCAT (`NAME`,`SURNAME`,`AADHAR_NUMBER`,`ACCOUNT_NUMBER`,`BLOOD_GROUP`,`BIRTH_DATE`,`MOBILE_NUMBER`,`ADDRESS`)LIKE ?");
        ps.setString(1,"%"+valueToSearch+"%");
        ResultSet rs=ps.executeQuery();
        DefaultTableModel model= (DefaultTableModel)table.getModel();
        Object[] row;
        while(rs.next())
        {
            row=new Object[10];
         row[0]=rs.getInt(1);
         row[1]=rs.getString(2);
          row[2]=rs.getString(3);
           row[3]=rs.getString(4);
            row[4]=rs.getString(5);
             row[5]=rs.getString(6);
             row[6]=rs.getString(7); 
             row[7]=rs.getString(8);
            row[8]=rs.getString(9);
            row[9]=rs.getString(10);
            
            model.addRow(row);
            
            
            
            
        }
        } catch (SQLException ex) {
            Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

    
    

    
