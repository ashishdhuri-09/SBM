
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vidya
 */
public class Busadd {
    public void insertUpdateDeleteBus(char operation,Integer id, String driver,
            String bno,String sname,String ppoint,String dpoint,String fees,String mobile)
    {
        Connection con= MyConnection.getConnection();
        PreparedStatement ps;
        if (operation== 'b'){
            try {
                ps=con.prepareStatement("INSERT INTO bus(driver, bno, sname, ppoint, dpoint, fees, mobile) VALUES (?,?,?,?,?,?,?)");
           ps.setString(1,driver);
           ps.setString(2,bno);
           ps.setString(3,sname);
           ps.setString(4,ppoint);
           ps.setString(5,dpoint);
           ps.setString(6,fees);
           ps.setString(7,mobile);
           
            if(ps.executeUpdate()>0)
            {
                JOptionPane.showMessageDialog(null,"New Bus Record Added");
            }
            
            } catch (SQLException ex) {
                Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
            }
        }}
        
    
}
