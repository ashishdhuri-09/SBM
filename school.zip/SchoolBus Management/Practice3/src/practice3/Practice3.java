/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice3;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Vidya
 */
public class Practice3 extends JFrame implements ListSelectionListener {
    JLabel l1;
    JTextField jtf;
    JList list;
    String name []={"book1","book2","book3","book4","book5"};
    
    public Practice3()
    {
        Container cp=getContentPane();
        cp.setLayout(new BorderLayout());
        l1=new JLabel("select a book");
        cp.add(l1,BorderLayout.NORTH);
        list=new JList(name);
        list.addListSelectionListener(this);
        cp.add(list,BorderLayout.CENTER);
        jtf=new JTextField(15);
        cp.add(jtf,BorderLayout.SOUTH);
        
        
    }
    public void valueChanged(ListSelectionEvent le)
    { int i=list.getSelectedIndex();
    if(i==0)
    {
        jtf.setText("book1 is selected");
       
    }
    else if(i==1)
    {
        jtf.setText("book2 is selected");
    }
    else if(i==2)
    {
        jtf.setText("book3 is selected");
    }
    else if(i==3)
    {
        jtf.setText("book4 is selected");
    }
    else if(i==4)
    {
        jtf.setText("book5 is selected");
    }
    else{
        jtf.setText("select a book");
    }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Practice3 p3=new Practice3();
        p3.setSize(400,400);
        p3.setTitle("student Detailes");
        p3.setVisible(true);
        p3.setDefaultCloseOperation(EXIT_ON_CLOSE);
        // TODO code application logic here
    }

    
}
